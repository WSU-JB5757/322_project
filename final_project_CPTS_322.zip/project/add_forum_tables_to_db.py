import sqlite3

# Connect to your existing database
conn = sqlite3.connect('website_backend.db')
c = conn.cursor()

# Create forum_data table
c.execute('''
CREATE TABLE IF NOT EXISTS forum_data (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    author TEXT NOT NULL,
    post_date TEXT NOT NULL,
    content TEXT NOT NULL,
    keywords TEXT,
    visible BOOLEAN DEFAULT 1
)
''')

# Create forum_comments table
c.execute('''
CREATE TABLE IF NOT EXISTS forum_comments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    forum_id INTEGER NOT NULL,
    author TEXT NOT NULL,
    comment TEXT NOT NULL,
    visible BOOLEAN DEFAULT 1,
    FOREIGN KEY(forum_id) REFERENCES forum_data(id) ON DELETE CASCADE
)
''')

# Commit changes and close connection
conn.commit()
conn.close()

print("Tables forum_data and forum_comments have been created (if they didn't already exist).")
