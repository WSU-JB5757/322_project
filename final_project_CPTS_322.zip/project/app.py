from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
import base64
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'secret_session_key'

# LOGIN LOGIC
def check_login(username, password):
    conn = sqlite3.connect('website_backend.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE username=? AND password=?", (username, password))
    user = cursor.fetchone()
    conn.close()
    return user

@app.route('/index')
def index():
    conn = sqlite3.connect('website_backend.db')
    cursor = conn.cursor()

    cursor.execute("SELECT id, username, image, document FROM users")
    users = cursor.fetchall()
    conn.close()

    processed_users = []
    for user in users:
        image_data = user[2]
        document_data = user[3]

        if isinstance(image_data, str):
            image_data = image_data.encode('utf-8')
        if isinstance(document_data, str):
            document_data = document_data.encode('utf-8')

        img_b64 = base64.b64encode(image_data).decode('utf-8') if image_data else None
        doc_b64 = base64.b64encode(document_data).decode('utf-8') if document_data else None

        processed_users.append({
            'id': user[0],
            'username': user[1],
            'image': img_b64,
            'document': doc_b64
        })

    return render_template('index.html', users=processed_users)

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = sqlite3.connect('website_backend.db')
        cursor = conn.cursor()
        cursor.execute("SELECT id, username, password FROM users WHERE username = ?", (username,))
        user = cursor.fetchone()

        if user and user[2] == password:
            session['user_id'] = user[0]
            session['username'] = user[1]
            flash('Login successful!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Invalid username or password.', 'danger')

    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))

@app.route('/profile')
def profile():
    user_id = session.get('user_id')
    if not user_id:
        return render_template('profile.html', user=None)

    conn = sqlite3.connect('website_backend.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
    user = cursor.fetchone()

    if user:
        user = dict(user)
    if user['image']:
        user['image'] = base64.b64encode(user['image']).decode('utf-8')
    if user['document']:
        user['document'] = base64.b64encode(user['document']).decode('utf-8')

    return render_template('profile.html', user=user)

@app.route('/edit_user/<int:user_id>', methods=['POST'])
def edit_user(user_id):
    conn = sqlite3.connect('website_backend.db')
    c = conn.cursor()

    username = request.form['username']
    image = request.files.get('image')
    document = request.files.get('document')

    update_fields = {'username': username}
    if image:
        update_fields['image'] = image.read()
    if document:
        update_fields['document'] = document.read()

    set_clause = ", ".join([f"{key} = ?" for key in update_fields.keys()])
    values = list(update_fields.values()) + [user_id]

    c.execute(f"UPDATE users SET {set_clause} WHERE id = ?", values)
    conn.commit()
    conn.close()

    flash("User info updated successfully.")
    return redirect(url_for('profile'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password'].strip()

        if not username or not password:
            return render_template('register.html', error="Both fields are required.")

        conn = sqlite3.connect('website_backend.db')
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
        existing_user = cursor.fetchone()
        if existing_user:
            conn.close()
            return render_template('register.html', error="Username already taken.")

        with open("static/images/blank.png", "rb") as f:
            default_image = f.read()
        default_document = b''

        cursor.execute(
            "INSERT INTO users (username, password, image, document) VALUES (?, ?, ?, ?)",
            (username, password, default_image, default_document)
        )
        conn.commit()
        conn.close()
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/blog')
def blog():
    keyword = request.args.get('keyword', '').strip().lower()

    conn = sqlite3.connect('website_backend.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    if keyword:
        cursor.execute("SELECT * FROM blogs WHERE LOWER(keywords) LIKE ?", ('%' + keyword + '%',))
        posts = cursor.fetchall()
        match_message = f"Search results for: '{keyword}'" if posts else "No match found."
    else:
        cursor.execute("SELECT * FROM blogs ORDER BY date_posted DESC")
        posts = cursor.fetchall()
        match_message = None

    conn.close()
    return render_template("blog.html", posts=posts, match_message=match_message)

@app.route('/blog/<int:blog_id>')
def view_blog(blog_id):
    conn = sqlite3.connect('website_backend.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM blogs WHERE id = ?", (blog_id,))
    blog = cursor.fetchone()

    cursor.execute("""
        SELECT * FROM comments 
        WHERE blog_id = ? AND show_comment = 1
        ORDER BY id ASC
    """, (blog_id,))
    comments = cursor.fetchall()
    conn.close()

    return render_template("view_blog.html", blog=blog, comments=comments)

@app.route("/submit_comment/<int:blog_id>", methods=['POST'])
def submit_comment(blog_id):
    author = request.form.get('author', '').strip()
    text = request.form.get('text', '').strip()

    if not author or not text:
        flash("Both name and comment text are required.", "warning")
        return redirect(url_for('view_blog', blog_id=blog_id))

    conn = sqlite3.connect('website_backend.db')
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO comments (blog_id, author, text) VALUES (?, ?, ?)",
        (blog_id, author, text)
    )
    conn.commit()
    conn.close()

    flash("Comment added!", "success")
    return redirect(url_for('view_blog', blog_id=blog_id))

# FORUM PAGE (Fixed)
@app.route("/forum", methods=['GET', 'POST'])
def forum():
    conn = sqlite3.connect('website_backend.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    if request.method == 'POST':
        author = request.form.get('author', '').strip()
        content = request.form.get('content', '').strip()

        if not author or not content:
            flash('Both name and content are required to post.', 'warning')
        else:
            post_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            cursor.execute(
                "INSERT INTO forum (author, content, post_date) VALUES (?, ?, ?)",
                (author, content, post_date)
            )
            conn.commit()
            flash('Post added successfully!', 'success')
            return redirect(url_for('forum'))

    search_query = request.args.get('search', '').strip().lower()
    if search_query:
        cursor.execute("SELECT * FROM forum WHERE LOWER(content) LIKE ?", ('%' + search_query + '%',))
    else:
        cursor.execute("SELECT * FROM forum ORDER BY post_date DESC")

    forums = cursor.fetchall()  # <<== NOW CORRECT
    conn.close()

    return render_template("forum.html", forums=forums)

# FORUM POST PAGE
@app.route("/forum/<int:forum_id>")
def forum_post(forum_id):
    conn = sqlite3.connect('website_backend.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM forum WHERE id = ?", (forum_id,))
    forum = cursor.fetchone()

    cursor.execute("""
        SELECT * FROM forum_comments 
        WHERE forum_id = ? AND visible = 1
        ORDER BY id ASC
    """, (forum_id,))
    comments = cursor.fetchall()

    conn.close()

    if forum:
        return render_template("view_forum.html", forum=forum, comments=comments)
    else:
        flash("Forum post not found.", "warning")
        return redirect(url_for('forum'))

# SUBMIT FORUM COMMENT
@app.route("/submit_forum_comment/<int:forum_id>", methods=['POST'])
def submit_forum_comment(forum_id):
    author = request.form.get('author', '').strip()
    comment = request.form.get('comment', '').strip()

    if not author or not comment:
        flash("Both name and comment are required.", "warning")
        return redirect(url_for('forum_post', forum_id=forum_id))

    conn = sqlite3.connect('website_backend.db')
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO forum_comments (forum_id, author, comment) VALUES (?, ?, ?)",
        (forum_id, author, comment)
    )
    conn.commit()
    conn.close()

    flash("Comment added!", "success")
    return redirect(url_for('forum_post', forum_id=forum_id))

@app.route("/classes")
def classes():
    return render_template("classes.html")

@app.route("/archive")
def archive():
    return render_template("archive.html")

@app.route("/scholarships")
def scholarships():
    return render_template("scholarships.html")

@app.route("/options")
def options():
    return render_template("options.html")

@app.route("/help")
def help():
    return render_template("help.html")

@app.route("/privacy")
def privacy():
    return render_template("privacy.html")

if __name__ == '__main__':
    app.run(debug=True)