from flask import Flask, render_template
import sqlite3
import base64

app = Flask(__name__)

@app.route('/')
def index_profile():
    conn = sqlite3.connect('website_backend.db')
    cursor = conn.cursor()

    cursor.execute("SELECT id, username, image, document FROM users")
    users = cursor.fetchall()
    conn.close()

    # Convert binary data to base64 strings for HTML display
    processed_users = []
    for user in users:
        img_b64 = base64.b64encode(user[2]).decode('utf-8') if user[2] else None
        doc_b64 = base64.b64encode(user[3]).decode('utf-8') if user[3] else None
        processed_users.append({
            'id': user[0],
            'username': user[1],
            'image': img_b64,
            'document': doc_b64
        })

    return render_template('index.html', users=processed_users)

if __name__ == '__main__':
    app.run(debug=True)
