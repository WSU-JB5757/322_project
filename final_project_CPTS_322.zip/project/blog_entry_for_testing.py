import sqlite3
from datetime import datetime

# Connect to the database
conn = sqlite3.connect('website_backend.db')
cursor = conn.cursor()

# Sample test blog data
title = "Test Blog Post"
author = "Test Author"
date_posted = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
content = "This is a test blog post to check the database functionality."
keywords = ["flask", "sqlite", "blog", "test", "entry", "example"]

# Insert into blogs table
cursor.execute('''
    INSERT INTO blogs (title, author, date_posted, content, keyword1, keyword2, keyword3, keyword4, keyword5, keyword6)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
''', (title, author, date_posted, content, *keywords))

conn.commit()
conn.close()

print("Test blog post added successfully!")
