import sqlite3
import base64

def is_base64_string(s):
    """Check if a string is likely base64-encoded."""
    try:
        # Decode and re-encode to check validity
        return base64.b64encode(base64.b64decode(s)) == s.encode()
    except Exception:
        return False

def clean_database(db_path='website_backend.db'):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    cursor.execute("SELECT id, image, document FROM users")
    users = cursor.fetchall()

    for user in users:
        user_id, image, document = user
        updates = {}

        # Check and decode image
        if image and isinstance(image, str) and is_base64_string(image):
            try:
                updates['image'] = base64.b64decode(image)
                print(f"[✔] Fixed image for user_id {user_id}")
            except Exception as e:
                print(f"[!] Failed to decode image for user_id {user_id}: {e}")

        # Check and decode document
        if document and isinstance(document, str) and is_base64_string(document):
            try:
                updates['document'] = base64.b64decode(document)
                print(f"[✔] Fixed document for user_id {user_id}")
            except Exception as e:
                print(f"[!] Failed to decode document for user_id {user_id}: {e}")

        # Apply updates if any
        if updates:
            set_clause = ", ".join([f"{key} = ?" for key in updates.keys()])
            values = list(updates.values()) + [user_id]
            cursor.execute(f"UPDATE users SET {set_clause} WHERE id = ?", values)

    conn.commit()
    conn.close()
    print("✅ Cleanup complete.")

if __name__ == "__main__":
    clean_database()
