import sqlite3

conn = sqlite3.connect('website_backend.db')
cursor = conn.cursor()

cursor.execute('''
    CREATE TABLE IF NOT EXISTS comments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        blog_id INTEGER NOT NULL,
        author TEXT NOT NULL,
        text TEXT NOT NULL,
        show_comment BOOLEAN DEFAULT 1,
        FOREIGN KEY (blog_id) REFERENCES blogs(id)
    )
''')

conn.commit()
conn.close()
