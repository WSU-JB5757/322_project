import sqlite3

# Connect to (or create) the SQLite database
conn = sqlite3.connect('website_backend.db')
cursor = conn.cursor()

# Create the users table if it doesn't exist
cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        image BLOB,
        document BLOB
    )
''')

# Create the blogs table if it doesn't exist
cursor.execute('''
    CREATE TABLE IF NOT EXISTS blogs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        author TEXT NOT NULL,
        date_posted TEXT NOT NULL,
        content TEXT NOT NULL,
        keyword1 TEXT,
        keyword2 TEXT,
        keyword3 TEXT,
        keyword4 TEXT,
        keyword5 TEXT,
        keyword6 TEXT
    )
''')

# Commit changes and close connection
conn.commit()
conn.close()

print("Database and tables initialized successfully.")
