import sqlite3

# Connect to your database
conn = sqlite3.connect('website_backend.db')
c = conn.cursor()

# Create the 'forum' table
c.execute('''
    CREATE TABLE IF NOT EXISTS forum (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        author TEXT NOT NULL,
        content TEXT NOT NULL,
        post_date TEXT NOT NULL
    )
''')

# Save and close
conn.commit()
conn.close()

print("Database initialized! Table 'forum' created if it didn't exist.")
