import sqlite3

def insert_user(username, password, image_path, document_path):
    # Read the image in binary mode
    with open(image_path, 'rb') as img_file:
        img_data = img_file.read()

    # Read the .rtf document in binary mode
    with open(document_path, 'rb') as doc_file:
        doc_data = doc_file.read()

    # Connect to the SQLite database
    conn = sqlite3.connect('website_backend.db')
    cursor = conn.cursor()

    # Insert the user
    cursor.execute('''
        INSERT INTO users (username, password, image, document)
        VALUES (?, ?, ?, ?)
    ''', (username, password, img_data, doc_data))

    # Commit and close
    conn.commit()
    conn.close()

# Example usage
insert_user(
    username='default_user',
    password='secretpassword123',
    image_path='stitchclose.jpeg',
    document_path='stitch_res.rtf'
)
