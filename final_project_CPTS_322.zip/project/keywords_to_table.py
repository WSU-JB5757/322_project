import sqlite3

conn = sqlite3.connect('website_backend.db')
cursor = conn.cursor()

# Update blog with ID 1 (change the ID as needed)
cursor.execute('''
    UPDATE blogs SET keywords = ? WHERE id = ?
''', ("python, ai, tech", 1))

conn.commit()
conn.close()


