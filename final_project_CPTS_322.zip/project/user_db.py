import sqlite3

# Connect to (or create) the SQLite database
conn = sqlite3.connect('website_backend.db')
cursor = conn.cursor()

# Create the users table
cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        image BLOB,
        document BLOB
    )
''')

# Commit changes and close connection
conn.commit()
conn.close()